package com.bean.springcloud.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;
import com.bean.pojo.Dept;

import java.util.List;

@Mapper
@Repository
public interface DeptDao {

     boolean addDept(Dept dept);

     Dept queryById(Long id);

     List<Dept> queryAll();

}
