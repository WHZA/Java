package com.bean.springcloud;


import com.bean.ribbonconfig.RibbonConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableEurekaClient //注解
@RibbonClient(name = "SPRINGCLOUD-PROVIDER-DEPT",configuration = RibbonConfig.class)    //name指的是应用名称，也就是服务提供者的spring.application.name = springcloud-provider-dept
public class DeptConsumer_80 {
    public static void main(String[] args) {
        SpringApplication.run(DeptConsumer_80.class,args);
    }
}