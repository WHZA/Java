package com.bean.ribbonconfig;

import com.netflix.client.config.IClientConfig;
import com.netflix.loadbalancer.AbstractLoadBalancerRule;
import com.netflix.loadbalancer.ILoadBalancer;
import com.netflix.loadbalancer.Server;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class MyRule extends AbstractLoadBalancerRule {


    /*
        需求：
        - A服务提供五次服务之后，假如服务B活着，跳转服务B
        - B服务提供五次服务之后，假如服务C活着，跳转服务C
        - C服务提供五次服务之后，假如服务A活着，跳转服务A
    */

    private int total = 0;  //我们设置一下当前服务被调用的次数
    private int currentIndex = 0;  //设置一下现在在哪个服务

    /*这个代码这么多，一看就是实现算法的地方*/
    public Server choose(ILoadBalancer lb, Object key) {
        if (lb == null) {   //假如没有负载均衡，就返回null
            return null;
        }
        Server server = null;

        while (server == null) {    //当没有服务的时候
            if (Thread.interrupted()) {
                return null;
            }
            List<Server> upList = lb.getReachableServers(); //获取还活着的服务
            List<Server> allList = lb.getAllServers();  //获取所有的服务


            /*-------------------------------------------------*/
            /*我们知道，这下面就是具体的算法，上边的都是前期的准备工作*/

//            int serverCount = allList.size();
//            if (serverCount == 0) {
//                return null;
//            }
//
//            int index = chooseRandomInt(serverCount);   //这个是索引，用于指向当前用哪个服务
//            server = upList.get(index); //让服务 = 从活着的服务里面获取新的服务

            //2. 我们把上面的全部都注释掉
            if (total<5){   //假如当前服务的调用次数小于5次
                server = upList.get(currentIndex);  //让服务为当前还活着的服务
                /*
                    这里就是优化了，我完全可以让server = allList.get(currentIndex)，但是这样的话假如服务崩了就没治了
                 */
                total++;    //让总数++
            }else {
                total = 0;  //假如超过了5次，那么对总数进行重置
                currentIndex++; //我们的游标也往前一位
                if (currentIndex>=upList.size()){
                    /*
                        假如游标 >= 还活着的总个数
                        这里应该是游标 >= 还活着的总数量，不要忘记我们的游标是从0开始的
                     */
                    currentIndex = 0;   //重置游标
                }
                server = upList.get(currentIndex); //从活着的服务中，获取指定的服务来进行操作
            }

            /*---------------------------------------------*/
            /*上面的就是具体的算法，下面就是一些收尾*/

            if (server == null) {   //假如服务没有获取到，还为null
                Thread.yield();     //进行处理，咋处理的也看不懂....
                continue;
            }

            if (server.isAlive()) { //假如这个服务还活着
                return (server);    //返回
            }

            server = null;  //服务置空
            Thread.yield(); //处理
        }

        return server;

    }


    /*下面这三个方法代码这么少，一看就不是实现算法的地方*/


    protected int chooseRandomInt(int serverCount) {
        return ThreadLocalRandom.current().nextInt(serverCount);
    }

	@Override
	public Server choose(Object key) {
		return choose(getLoadBalancer(), key);
	}

	@Override
	public void initWithNiwsConfig(IClientConfig clientConfig) {//这个方法都是空的，说明没啥用

    }
}
