package com.bean.springcloud.controller;

import com.bean.pojo.Dept;
import com.bean.springcloud.service.DeptService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/*把没用的Conctroller都删了*/
@RestController
public class DeptConrtoller {

    @Autowired
    private DeptService deptService;

    @GetMapping("/dept/get/{id}")
    @HystrixCommand(fallbackMethod = "hystrixGet")//假如服务崩了，会自动调用hystrixGet方法
    public Dept get(@PathVariable("id")Long id){
        Dept dept = deptService.queryById(id);
        /*
            这里有点问题：假如查找不存在的id，那么查出来就是null
            这么返回前端肯定爆出500
            那么这个时候就需要服务熔断
         */
        if (dept==null){
            //假如dept为null，那么直接抛出异常，模拟服务崩溃
            throw new RuntimeException();
        }

        return dept;
    }

    //服务熔断机制，服务崩了之后的备选方案
    public Dept hystrixGet(@PathVariable("id")Long id){
        return new Dept()
                    .setDname("id=>"+id+" 不存在，或者无法查询")
                    .setDb_source("no this database in MySQL");
    }



}
