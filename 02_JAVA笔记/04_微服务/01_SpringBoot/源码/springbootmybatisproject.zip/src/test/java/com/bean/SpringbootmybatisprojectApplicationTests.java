package com.bean;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

@SpringBootTest
class SpringbootmybatisprojectApplicationTests {

    @Autowired
    DataSource dataSource;

    @Test
    void contextLoads() throws SQLException {


        //class com.zaxxer.hikari.HikariDataSource
        System.out.println(dataSource.getClass());


        //HikariProxyConnection@246168102 wrapping com.mysql.cj.jdbc.ConnectionImpl@10b1a751
        Connection connection = dataSource.getConnection();
        System.out.println(connection);
    }

}
