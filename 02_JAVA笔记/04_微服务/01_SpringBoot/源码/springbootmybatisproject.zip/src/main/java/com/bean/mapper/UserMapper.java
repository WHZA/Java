package com.bean.mapper;

import com.bean.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

//@Mapper使用这个注解代表着这是一个mybats的mapper类
//或者直接在启动类上写@MapperScan("com.bean.mapper")代表着这个包下全都是mapper
@Mapper
@Repository
public interface UserMapper {

    List<User> queryUserList();

    User queryUserById();

    int addUser(User user);

    int updateUser(User user);

    int deleteUser(int id);

}
