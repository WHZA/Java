package com.bean.config;


import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    //授权规则
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        //首页所有人可以访问，功能页只对应有权限的人才可以访问

        //请求授权的规则
        http.authorizeRequests()
                .antMatchers("/").permitAll()               //首页所有人可以访问
                .antMatchers("/level1/**").hasRole("vip1")  //level1的只有vip1可以访问
                .antMatchers("/level2/**").hasRole("vip2")  //level2的只有vip2可以访问
                .antMatchers("/level3/**").hasRole("vip3"); //level3的只有vip3可以访问


        //没有权限我们让他去到登录页，自带登录页面
        //定制登录页：loginPage("/toLogin")
        http.formLogin()
                .loginPage("/toLogin")  //登陆的界面
                .usernameParameter("username")  //登录传过来的用户名的name
                .passwordParameter("password")  //登录传过来密码的name
                .loginProcessingUrl("/login")  //登录成功的界面
                .failureForwardUrl("/index"); //登陆失败的界面




        //防止网站攻击，默认是开启的
        // 现在我们关闭，这是因为这是登陆失败有可能的原因
        http.csrf().disable();

        /*
        注销，假如去看源码，
        会发现这个注销的请求路径为 /logout
        deleteCookies("remove") 清空cookie
        invalidateHttpSession(true)    清空session
        logoutSuccessUrl("/");     注销之后的界面，默认为自带的登录界面
         */
        http.logout().logoutSuccessUrl("/");



        //开启记住我功能，其实使用的就是cookie，这里的rememberMeParameter是传过来的name的值
        http.rememberMe().rememberMeParameter("remember");
    }


    //认证规则
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {

        //数据正常应该从数据库中读，这里也可以在数据库中读取
        //注意如果密码没有加密，在springboot2.1.x没有问题
        //但是在那之后就必须实现加密操作，否则会报错，这里使用一个加密方式passwordEncoder(new BCryptPasswordEncoder())
        auth.inMemoryAuthentication().passwordEncoder(new BCryptPasswordEncoder())
                .withUser("bean")   //添加用户名
                .password(new BCryptPasswordEncoder().encode("123456")) //添加这个密码
                .roles("vip2","vip3") //添加权限
                .and() //使用and()方法来继续下一个用户
                .withUser("root") //下一个用户的名字
                .password(new BCryptPasswordEncoder().encode("123456")) //下一个用户的密码
                .roles("vip1","vip2","vip3"); //下一个用户的权限
    }
}
