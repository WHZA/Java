package com.bean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringsecurityprojectApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringsecurityprojectApplication.class, args);
    }

}