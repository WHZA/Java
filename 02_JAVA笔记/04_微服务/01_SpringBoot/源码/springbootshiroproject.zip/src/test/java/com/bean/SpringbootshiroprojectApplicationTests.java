package com.bean;

import com.bean.service.UserServiceImpl;
import com.bean.pojo.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootshiroprojectApplicationTests {


    @Autowired
    UserServiceImpl userService;

    @Test
    void contextLoads() {

        User user = userService.selectUserByName("小王");
        System.out.println(user);//User(id=1, name=小王, pwd=zzzzz)
    }

}
