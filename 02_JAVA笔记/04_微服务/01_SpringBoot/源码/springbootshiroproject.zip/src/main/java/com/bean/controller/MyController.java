package com.bean.controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {

    @RequestMapping({"/","/index","/index.html"})
    public String index(Model model){
        model.addAttribute("message","Hello,World");
        return "index";
    }

    @RequestMapping("/user/add")
    public String add(){
        return "user/add";
    }

    @RequestMapping("/user/update")
    public String update(){
        return "user/update";
    }

    @RequestMapping("/toLogin")
    public String toLogin(){
        return "login";
    }

    //写一个登陆的页面
    @RequestMapping("/login")
    public String login(String username,String password,Model model){

        //这里看不出来和UserRealm有联系，但是确实有联系了

        // 获取用户信息，
        Subject subject = SecurityUtils.getSubject();

        //获取一个token信息，这个token会存到全局中，在任何类中都可以调用
        UsernamePasswordToken token = new UsernamePasswordToken(username, password);

        //执行登陆方法，如果没有异常说明没问题，但是我们通过快速开始知道有几个异常
        try {
            //执行完这个方法之后，它会跳转到UserRealm类中去执行认证方法，这里确实看出有联系了
            subject.login(token);
            return "index";
        } catch (UnknownAccountException e) { //用户名不存在，返回到登陆
            model.addAttribute("message","用户名错误");
            return "login";
        }catch (IncorrectCredentialsException e){//密码不存在，返回到登陆
            model.addAttribute("message","密码错误");
            return "login";
        }
    }

    @RequestMapping("/unauthorized")
    @ResponseBody
    public String unauthorized(){
        return "权限不足";
    }

}
