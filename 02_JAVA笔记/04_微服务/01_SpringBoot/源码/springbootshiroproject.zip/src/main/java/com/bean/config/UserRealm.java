package com.bean.config;

import com.bean.pojo.User;
import com.bean.service.UserServiceImpl;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;


//自定义的Realm，只需要继承AuthorizingRealm，然后重写两个方法
public class UserRealm extends AuthorizingRealm {

    @Autowired
    private UserServiceImpl userService;

    //授权
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {


        //从认证方法中拿出Object，这里是user
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();

        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        //从数据表中查找出权限，假如不为空则赋予权限
        if (!(user.getPerms()==null)){
            info.addStringPermission(user.getPerms());
        }

        //为空则返回null，会跳转到没有权限页面
        return info;
    }

    //认证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {


        UsernamePasswordToken userToken = (UsernamePasswordToken) authenticationToken;

        User user = userService.selectUserByName(userToken.getUsername());

        if (user==null){
            return null;
        }

        //注意这里，我们在这里的参数第一个是Object，用于传递到授权方法中
        //这个用户放在第一个位置上，可以传递到授权方法中
        return new SimpleAuthenticationInfo(user,user.getPwd(),"");
    }
}