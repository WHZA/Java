package com.bean.service;

import com.bean.pojo.User;
import org.springframework.stereotype.Service;

public interface UserService {
    User selectUserByName(String name);
}
