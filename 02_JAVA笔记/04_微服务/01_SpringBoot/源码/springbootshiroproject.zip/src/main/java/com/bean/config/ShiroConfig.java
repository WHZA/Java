package com.bean.config;

import at.pollux.thymeleaf.shiro.dialect.ShiroDialect;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.LinkedHashMap;
import java.util.Map;

@Configuration
public class ShiroConfig {

    @Bean
    public UserRealm userRealm(){
        return new UserRealm();
    }

    @Bean(name = "manager")
    public DefaultWebSecurityManager defaultWebSecurityManager(@Qualifier("userRealm") UserRealm realm){
        DefaultWebSecurityManager manager = new DefaultWebSecurityManager();

        //关联realm
        manager.setRealm(realm);
        return manager;
    }

    @Bean
    public ShiroFilterFactoryBean shiroFilterFactoryBean(@Qualifier("manager") DefaultWebSecurityManager manager){
        ShiroFilterFactoryBean bean = new ShiroFilterFactoryBean();

        bean.setSecurityManager(manager);

        Map<String, String> filterMap = new LinkedHashMap<>();


        //还是在ShiroConfig这个Shiro配置类中，如果要访问/user/add这个路径，则
        //perms[user:add]：首先是user这个用户，而且用户必须有add权限
        //否则会跳转到权限不足的页面
        filterMap.put("/user/add","perms[user:add]");
        //权限不足默认请求这个路径
        //权限验证一定要放在登陆验证的前面，否则不会起作用，我也不知道为啥
        bean.setUnauthorizedUrl("/unauthorized");


        filterMap.put("/user/*","authc");

        bean.setLoginUrl("/toLogin");

        bean.setFilterChainDefinitionMap(filterMap);

        return bean;
    }

    //整合Shiro-Thymeleaf
    @Bean
    public ShiroDialect shiroDialect(){
        return new ShiroDialect();
    }
}
