package com.bean.mapper;

import com.bean.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface UserMapper {
    User selectUserByName(String name);
}
