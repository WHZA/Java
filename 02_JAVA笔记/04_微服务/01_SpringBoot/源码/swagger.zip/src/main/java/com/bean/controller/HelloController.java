package com.bean.controller;

import com.bean.pojo.Student;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HelloController {


    @PostMapping("/hello")
    @ResponseBody
    @ApiOperation("Hello控制")
    public String hello(){
        return "hello";
    }


    @PostMapping("/hello2")
    @ResponseBody
    @ApiOperation("Hello2控制")
    public Student hello2(@ApiParam("用户名") String username){
        return new Student();
    }
}
