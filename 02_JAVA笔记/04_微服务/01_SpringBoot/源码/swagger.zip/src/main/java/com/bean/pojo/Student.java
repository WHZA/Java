package com.bean.pojo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("学生实体类")
public class Student {

    @ApiModelProperty("id")
    private int id;

    @ApiModelProperty("用户名")
    public String username;

    @ApiModelProperty("密码")
    public String password;

}
