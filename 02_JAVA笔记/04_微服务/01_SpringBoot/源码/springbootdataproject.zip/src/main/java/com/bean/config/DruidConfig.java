package com.bean.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.support.http.StatViewServlet;
import com.alibaba.druid.support.http.WebStatFilter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class DruidConfig {

    @ConfigurationProperties(prefix = "spring.datasource")
    @Bean
    public DataSource druidDataSourceConfig(){
        return new DruidDataSource();
    }


    /*配置Druid数据源监控
    * 这个就相当于web.xml
    * */
    @Bean
    public ServletRegistrationBean statViewServlet(){
        //配置Servlet注册bean，参数为StatViewServlet：统计视图servlet，等会的访问路径可以为 /druid/**，约定俗成的就是这个路径
        ServletRegistrationBean bean = new ServletRegistrationBean(new StatViewServlet(),"/druid/*");

        HashMap<String, String> initParameters = new HashMap<>();


        //注意这两个登陆名和密码的key值为固定参数
        initParameters.put("loginUsername","admin");//后台管理界面的登陆账号
        initParameters.put("loginPassword","123456");//后台管理界面的登陆密码

        //后台允许谁可以访问，假如为localhost那就只有本机可以访问
        // 为""或者null则表明所有人可以访问
        initParameters.put("allow","");


        //后台谁不可以访问，比如禁止谁不能访问
        // 然后给一个ip地址
//        initParameters.put("bean","ip");


        //设置好初始化参数
        bean.setInitParameters(initParameters);


        return bean;
    }





    /*配置DruidWebFilter
     * 这个过滤的多用就是统计web应用请求中所有的数据库信息，
     * 比如发出的sql语句，执行时间，请求次数，请求的url地址
     * session，数据库表的访问次数等等
     * */
    @Bean
    public FilterRegistrationBean webStatFilter(){

        FilterRegistrationBean bean = new FilterRegistrationBean();

        bean.setFilter(new WebStatFilter());

        //exclusion：设置那些请求过滤排除掉,不进行统计
        Map<String,String> initParams = new HashMap<>();

        initParams.put("exclusions","*.js,*.css,/druid/*");

        bean.setInitParameters(initParams);


        // /*表示过滤所有请求
        bean.setUrlPatterns(Arrays.asList("/*"));

        return bean;
    }

}
