package com.bean.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
public class JDBCController {


    //在springBoot中会有很多的xxxxTemplate，这是SpringBoot已经配制好的模版bean，拿来即用CRUD即可
    @Autowired
    JdbcTemplate jdbcTemplate;

    //查询数据库中的所有信息
    //没有实体类，那么数据库中的东西如何获取，我们可以使用Map
    @RequestMapping("/list")
    public List<Map<String,Object>> userList(){

        return jdbcTemplate.queryForList("select * from user");
    }

    @RequestMapping("/addUser")
    public String addUser(){

        String sql = "insert into user(id,name,pwd) values (7,'小明','123456')";

        int update = jdbcTemplate.update(sql);

        return "OK";
    }

    @RequestMapping("/updateUser/{id}")
    public String updateUser(@PathVariable("id") String id){


        String sql = "update user set name = ?,pwd=? where id="+id;

        Object[] objects = new Object[2];
        objects[0] = "小王";
        objects[1] = "zzzzz";

        int update = jdbcTemplate.update(sql,objects);

        return "OK";
    }

    @RequestMapping("/deleteUser/{id}")
    public String deleteUser(@PathVariable("id") String id){

        String sql = "delete from user where id=?";

        int update = jdbcTemplate.update(sql,id);

        return "OK";
    }
}
