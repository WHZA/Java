package com.bean.service;


//这里也是一个比较坑的地方：因为我们调用的是其他项目的方法，没有自动提示
//所以我们要在自己的项目中写一个接口，不用写实现类
//这个接口要注意，路径必须完全相同：com.bean.service.TicketService
public interface TicketService {
    String getTicket();
}
