package com.bean.service;

import org.apache.dubbo.config.annotation.Reference;
import org.springframework.stereotype.Service;

//这个方法是使用的方法
@Service    //这里注意，这里使用的注解是Spring的，不是Dubbo的
public class UserService {

    //自动注入，类似@Autowried，但是我们注入的不是本地方法，是RPC协议的
    //注意，导入的包是dubbo的
    @Reference
    TicketService ticketService;

    public void use(){
        String ticket = ticketService.getTicket();
        System.out.println(ticket);
    }
}
