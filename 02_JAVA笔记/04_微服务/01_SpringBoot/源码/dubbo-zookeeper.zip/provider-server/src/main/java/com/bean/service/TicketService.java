package com.bean.service;

public interface TicketService {
    String getTicket();
}
