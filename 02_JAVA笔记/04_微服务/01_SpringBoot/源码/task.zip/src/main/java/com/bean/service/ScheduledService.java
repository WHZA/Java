package com.bean.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class ScheduledService {

    @Scheduled(cron = "*/5 * * ? * 6")
    public void hello(){
        System.out.println("在特定的时间执行这个方法");
    }
}
