package com.bean;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.File;

@SpringBootTest
class DemoApplicationTests {

    @Autowired
    JavaMailSenderImpl mailSender;

    @Test
    void contextLoads() {

        SimpleMailMessage message = new SimpleMailMessage();


        //收件人标题
        message.setSubject("收件人");
        //文本
        message.setText("文本");
        //收件人
        message.setTo("2592716753@qq.com");
        //发件人
        message.setFrom("2592716753@qq.com");


        mailSender.send(message);
    }


    @Test
    void contextLoads2() throws MessagingException {


        MimeMessage message = mailSender.createMimeMessage();

        //这个有四个重载：MimeMessage（复杂邮件），multipart（支持多文件），encoding(支持编码)
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        //标题
        helper.setSubject("复杂类型邮件");

        //正文，这个也有重载：text（文本）,html（html支持）
        helper.setText("<p style='color:red'>正文</p>",true);

        //添加附件
        helper.addAttachment("1.txt",new File("C:\\Users\\Bean\\Desktop\\1.txt"));

        //发件人
        message.setFrom("2592716753@qq.com");

        //收件人
        helper.setTo("2592716753@qq.com");


        mailSender.send(message);
    }
}
