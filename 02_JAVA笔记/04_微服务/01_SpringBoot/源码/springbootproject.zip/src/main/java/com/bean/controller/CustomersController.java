package com.bean.controller;

import com.bean.dao.DepartmentDao;
import com.bean.dao.EmployeeDao;
import com.bean.pojo.Department;
import com.bean.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

@Controller
public class CustomersController {

    @Autowired
    EmployeeDao employeeDao;
    @Autowired
    DepartmentDao departmentDao;

    /*具体的作用是跳转到员工列表*/
    @RequestMapping("/customers")
    public String customers(Model model){
        /*这里将员工数据添加进去，并且返回到指定的页面*/
        model.addAttribute("customers",employeeDao.getAll());
        return "customers/list";
    }


    /*具体的作用是跳转到添加员工界面，并且交给部门的动态数据*/
    @GetMapping("/addcustomers")
    public String addCustomers(Model model){
        Collection<Department> departments = departmentDao.getDepartments();
        model.addAttribute("departments",departments);
        return "customers/addcustomers";
    }

    /*具体的作用是添加员工信息，其实应该调用service层*/
    @PostMapping("/addcustomers")
    public String addCustomers(Employee employee){

        employeeDao.save(employee);

        /*重定向到 /customers 请求下，让他再去访问一遍员工数据*/
        return "redirect:/customers";
    }


    /*进入到修改页面*/
    @GetMapping("/updatecustomers/{id}")
    public String updateCustomers(@PathVariable("id") Integer id,Model model){

        Employee employee = employeeDao.getEmployeeById(id);

        Collection<Department> departments = departmentDao.getDepartments();

        model.addAttribute("employee",employee);
        model.addAttribute("departments",departments);


        return "customers/updatecustomers";
    }

    /*修改后跳转界面*/
    @PostMapping("/updatecustomers")
    public String updateCustomers(Employee employee){

        //虽然这里应该有一个修改的内容，但是我没写，就当修改完了，走一遍流程

        return "redirect:/customers";
    }


    /*进入到删除页面*/
    @GetMapping("/deletecustomers/{id}")
    public String deleteCustomers(@PathVariable("id") Integer id,Model model){

        employeeDao.delete(id);

        return "redirect:/customers";
    }
}
