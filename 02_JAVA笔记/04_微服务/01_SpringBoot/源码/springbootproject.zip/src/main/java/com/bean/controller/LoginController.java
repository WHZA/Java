package com.bean.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.thymeleaf.util.StringUtils;

import javax.servlet.http.HttpSession;

@Controller
public class LoginController {

    @RequestMapping("/login")
    public String login(@RequestParam("username") String username, @RequestParam("password") String password, Model model, HttpSession session){

        /*重写一下controller，增加一个用户登录成功返回的session*/
        if (!StringUtils.isEmpty(username) && password.equals("123456")){
            session.setAttribute("session",username);
            return "redirect:/main";
        }else {
            model.addAttribute("msg","用户名或者密码错误");
            return "redirect:/index";
        }
    }
}
