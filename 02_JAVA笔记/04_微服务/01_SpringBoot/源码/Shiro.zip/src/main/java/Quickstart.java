import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.config.IniSecurityManagerFactory;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.util.Factory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class Quickstart {

    //开启日志
    private static final transient Logger log = LoggerFactory.getLogger(Quickstart.class);


    public static void main(String[] args) {

        //工厂，找到classpath:shiro.ini，就是刚才导入的那个shiro.ini
        Factory<SecurityManager> factory = new IniSecurityManagerFactory("classpath:shiro.ini");

        //获取SecurityManage
        SecurityManager securityManager = factory.getInstance();

        //Subject，这个很重要
        Subject currentUser = SecurityUtils.getSubject();

        //它可以获取Session，注意这个Session不是HttpSession，而是ShiroSession
        Session session = currentUser.getSession();
        //设置值
        session.setAttribute("someKey", "aValue");
        //获取值
        String value = (String) session.getAttribute("someKey");
        if (value.equals("aValue")) {
            log.info("Session==>[" + value + "]");
        }

        // 用户是否认证
        if (!currentUser.isAuthenticated()) {
            //设置Token
            UsernamePasswordToken token = new UsernamePasswordToken("lonestarr", "vespa");
            //设置记住我
            token.setRememberMe(true);
            try {
                //用户登录
                currentUser.login(token);
            } catch (UnknownAccountException uae) {
                //异常1：用户名错误
                log.info("There is no user with username of " + token.getPrincipal());
            } catch (IncorrectCredentialsException ice) {
                //异常2：密码错误
                log.info("Password for account " + token.getPrincipal() + " was incorrect!");
            } catch (LockedAccountException lae) {
                //异常3：多次登陆失败之后锁定用户
                log.info("The account for username " + token.getPrincipal() + " is locked.  " +
                        "Please contact your administrator to unlock it.");
            }
            // ... catch more exceptions here (maybe custom ones specific to your application?
            catch (AuthenticationException ae) {
                //异常4：总异常
            }
        }

        //获取当前用户的认证码，可以存储信息
        log.info("User [" + currentUser.getPrincipal() + "] logged in successfully.");

        //测试角色，当前用户的角色（权限）
        if (currentUser.hasRole("schwartz")) {
            log.info("May the Schwartz be with you!");
        } else {
            log.info("Hello, mere mortal.");
        }

        //检测是否有权限（粗力度）
        if (currentUser.isPermitted("lightsaber:wield")) {
            log.info("You may use a lightsaber ring.  Use it wisely.");
        } else {
            log.info("Sorry, lightsaber rings are for schwartz masters only.");
        }

        //检测是否有权限（细力度）
        if (currentUser.isPermitted("winnebago:drive:eagle5")) {
            log.info("You are permitted to 'drive' the winnebago with license plate (id) 'eagle5'.  " +
                    "Here are the keys - have fun!");
        } else {
            log.info("Sorry, you aren't allowed to drive the 'eagle5' winnebago!");
        }

        //注销
        currentUser.logout();

        System.exit(0);
    }
}