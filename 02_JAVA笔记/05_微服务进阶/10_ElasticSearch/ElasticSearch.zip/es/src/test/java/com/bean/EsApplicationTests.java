package com.bean;


import com.alibaba.fastjson.JSON;
import com.bean.pojo.User;
import org.apache.lucene.util.QueryBuilder;
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequest;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.support.master.AcknowledgedResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.IndicesClient;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.get.GetResult;
import org.elasticsearch.index.query.MatchAllQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@SpringBootTest
class EsApplicationTests {

    @Autowired
    @Qualifier("restHighLevelClient")
    private RestHighLevelClient client;

    //创建索引
    @Test
    void createIndex() throws IOException {
        //创建一个请求，请求包含创建的索引
        CreateIndexRequest request = new CreateIndexRequest("bean_test");

        //这个indicesClinet包含了所有东西
        IndicesClient indices = client.indices();

        //创建索引，把请求给他，请求设置就使用默认的就好
        CreateIndexResponse createIndexResponse = indices.create(request, RequestOptions.DEFAULT);

        //打印一下看看什么东西:org.elasticsearch.client.indices.CreateIndexResponse@8a7f4660
        System.out.println(createIndexResponse);
    }

    //查看索引是否存在
    @Test
    void isExistIndex() throws IOException {
        //创建一个请求，请求包含创建的索引

        GetIndexRequest request = new GetIndexRequest("bean_test");

        IndicesClient indices = client.indices();

        boolean exists = indices.exists(request, RequestOptions.DEFAULT);

        System.out.println(exists);
    }

    //删除索引
    @Test
    void deleteIndex() throws IOException {
        DeleteIndexRequest request = new DeleteIndexRequest("bean_test");

        AcknowledgedResponse delete = client.indices().delete(request, RequestOptions.DEFAULT);

        //查看是否删除成功
        System.out.println(delete.isAcknowledged());
    }

    //插入文档
    @Test
    void indexDocument() throws IOException {
        User user = new User("bean", 10);

        //规则： put/bean_test/1
        IndexRequest request = new IndexRequest("bean_test");
        request.id("1");
        //设置超时时间为1s
        request.timeout(TimeValue.timeValueSeconds(1));

        //将数据放入json
        request.source(JSON.toJSONString(user), XContentType.JSON);

        //发送数据，获得相应
        IndexResponse response = client.index(request, RequestOptions.DEFAULT);

        System.out.println(request.toString());//返回索引信息：index {[bean_test][_doc][1], source[{"age":10,"name":"bean"}]}

        System.out.println(response.status());//返回当前的状态：CREATED

    }


    //文档是否存在
    @Test
    void existDocument() throws IOException {
        GetRequest request = new GetRequest("bean_test", "1");

        boolean exists = client.exists(request, RequestOptions.DEFAULT);

        System.out.println(exists);
    }

    //获得文档的具体信息
    @Test
    void getDocument() throws IOException {
        GetRequest request = new GetRequest("bean_test", "1");

        GetResponse getResponse = client.get(request, RequestOptions.DEFAULT);

        //打印文档内容：{"age":10,"name":"bean"}
        System.out.println(getResponse.getSourceAsString());

        //返回的全部的内容：{"_index":"bean_test","_type":"_doc","_id":"1","_version":2,"_seq_no":1,"_primary_term":1,"found":true,"_source":{"age":10,"name":"bean"}}
        System.out.println(getResponse);
    }

    //更新文档
    @Test
    void updateDocument() throws IOException {
        UpdateRequest request = new UpdateRequest("bean_test", "1");

        User user = new User("豌豆", 22);

        UpdateRequest doc = request.doc(JSON.toJSONString(user), XContentType.JSON);

        UpdateResponse updateResponse = client.update(request, RequestOptions.DEFAULT);

        //OK
        System.out.println(updateResponse.status());

    }

    //删除文档
    @Test
    void deleteDocument() throws IOException {

        DeleteRequest request = new DeleteRequest("bean_test", "1");

        DeleteResponse deleteResponse = client.delete(request, RequestOptions.DEFAULT);

        //OK
        System.out.println(deleteResponse.status());

    }

    //批量请求
    @Test
    void testBulkRequest() throws IOException {
        BulkRequest bulkRequest = new BulkRequest();

        List<User> list = new ArrayList<>();
        list.add(new User("bean1", 3));
        list.add(new User("bean2", 3));
        list.add(new User("bean3", 3));
        list.add(new User("bean4", 3));
        list.add(new User("bean5", 3));
        list.add(new User("bean6", 3));

        for (int i = 0; i < list.size(); i++) {
            bulkRequest.add(
                    new IndexRequest("bean_test")
                            .id("" + (i + 1))
                            .source(JSON.toJSONString(list.get(i)), XContentType.JSON)
            );
        }

        BulkResponse bulk = client.bulk(bulkRequest, RequestOptions.DEFAULT);
        System.out.println(bulk.hasFailures());//false，但是false代表的是成功
    }


    //查询
    @Test
    void search() throws IOException {
        SearchRequest request = new SearchRequest("bean_test");

        //利用这个搜索构建器可以构建出所有的查询条件，我们的原生所有的搜索条件都在这里
        SearchSourceBuilder builder = new SearchSourceBuilder();


        //比如我要使用高亮：builder.highlighter()
        //比如说我要分页：builder.from()，builder.size()
        //排序：builder.sort()

        //虽然所有的条件都在这里，但是有些需要一些构造器，比如query就需要一个query的builder
        //下面使用query作为一个例子：可以使用queryBuilders这个工具类进行快速匹配


//        MatchAllQueryBuilder queryBuilder = QueryBuilders.matchAllQuery();
        TermQueryBuilder queryBuilder = QueryBuilders.termQuery("name", "bean1");
        //查询
        builder.query(queryBuilder);

        //设置超时时间
        builder.timeout(new TimeValue(60, TimeUnit.SECONDS));

        //将搜索构建起放到请求里面
        request.source(builder);
        //执行
        SearchResponse search = client.search(request, RequestOptions.DEFAULT);

        //在之前我们就说过，hits里面都是具体的信息
        /*
            {
                "fragment":true,
                "hits":
                    [
                        {
                            "fields":{},
                            "fragment":false,
                            "highlightFields":{},
                            "id":"1",
                            "matchedQueries":[],
                            "primaryTerm":0,
                            "rawSortValues":[],
                            "score":1.540445,
                            "seqNo":-2,
                            "sortValues":[],
                            "sourceAsMap":{"name":"bean1","age":3},
                            "sourceAsString":"{\"age\":3,\"name\":\"bean1\"}",
                            "sourceRef":{"fragment":true},
                            "type":"_doc",
                            "version":-1
                        }
                    ],
                "maxScore":1.540445,
                "totalHits":{"relation":"EQUAL_TO","value":1}
            }
         */
        System.out.println(JSON.toJSONString(search.getHits()));

        System.out.println("==========================");

        ////{name=bean1, age=3}
        for (SearchHit hit : search.getHits().getHits()) {
            System.out.println(hit.getSourceAsMap());
        }
    }
}
