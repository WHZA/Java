package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ESStart {
    public static void main(String[] args) {
        SpringApplication.run(ESStart.class,args);
    }

}
