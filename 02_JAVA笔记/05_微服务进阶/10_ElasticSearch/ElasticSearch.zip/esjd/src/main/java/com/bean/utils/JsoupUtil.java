package com.bean.utils;

import com.bean.pojo.Content;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class JsoupUtil {

    public static List<Content> getMessage(String keyword) throws IOException {

        String url = "https://search.jd.com/Search?keyword="+keyword+"&enc=utf-8";

        List<Content> contents = new ArrayList<>();


        //返回的json
        Document document = Jsoup.parse(new URL(url), 3000);

        //获取所有的产品列表
        Element elements = document.getElementById("J_goodsList");
        //获取所有的li
        Elements li = elements.getElementsByTag("li");

        for (Element element : li) {
            //获取对应的图片
            String img = element.getElementsByTag("img").get(0).attr("src");
            //获取对应的价格
            String price = element.getElementsByClass("p-price").get(0).text();
            //获取对应的名称
            String name = element.getElementsByClass("p-name").get(0).getElementsByTag("em").text();

            contents.add(new Content(name,price,img));
        }
        return contents;
    }
}
