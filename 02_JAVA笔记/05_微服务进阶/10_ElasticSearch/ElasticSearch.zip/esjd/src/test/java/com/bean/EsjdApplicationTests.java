package com.bean;

import com.bean.pojo.Content;
import com.bean.utils.JsoupUtil;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

@SpringBootTest
class EsjdApplicationTests {

    @Test
    void contextLoads() throws IOException {

        List<Content> message = JsoupUtil.getMessage("你好");

        message.forEach(System.out::println);
    }

}
