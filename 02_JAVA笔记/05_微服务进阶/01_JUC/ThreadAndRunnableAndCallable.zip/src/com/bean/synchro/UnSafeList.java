package com.bean.synchro;

import java.util.ArrayList;
import java.util.List;

//线程不安全的集合
public class UnSafeList {
    public static void main(String[] args) {
        List<String> lists = new ArrayList<>();

        for (int i = 0; i < 10000; i++) {
            new Thread(()->{
               lists.add(Thread.currentThread().getName());
            }).start();
        }
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println(lists.size());   //9997
    }
}
