package com.bean.synchro;


public class UnSafeDemo {

    public static void main(String[] args) {
        BuyTicket buyTicket = new BuyTicket();

        new Thread(buyTicket,"A").start();
        new Thread(buyTicket,"B").start();
        new Thread(buyTicket,"C").start();
    }
}

class BuyTicket implements Runnable{

    private int ticket = 10;
    private boolean flag = true;
    @Override
    public void run() {
        while (flag){
            buy();
        }
    }

    private synchronized void buy(){    //我们只需要在修改的方法上加上同步标签，将这个方法改为同步方法
        if (ticket<=0){
            flag =false;
            return;
        }

        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println(Thread.currentThread().getName()+"-->"+ticket--);
    }
}