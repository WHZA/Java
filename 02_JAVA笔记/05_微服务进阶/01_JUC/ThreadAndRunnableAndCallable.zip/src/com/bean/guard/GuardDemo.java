package com.bean.guard;

public class GuardDemo {
    public static void main(String[] args) {
        Guard guard = new Guard();

        User user = new User();


        Thread userThread = new Thread(user);  //默认都是用户线程

        Thread guardThread = new Thread(guard); //默认都是用户线程
        guardThread.setDaemon(true);    //设置为守护线程，默认都是用户线程

        guardThread.start();
        userThread.start();
    }
}

class Guard implements Runnable{

    @Override
    public void run() {
        while (true){
            System.out.println("守护线程");
        }
    }
}


class User implements Runnable{

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            System.out.println("用户线程");
        }
    }
}