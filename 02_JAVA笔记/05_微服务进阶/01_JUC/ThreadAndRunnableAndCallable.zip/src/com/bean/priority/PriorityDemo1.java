package com.bean.priority;


//测试线程优先级
public class PriorityDemo1 extends Thread{

    public static void main(String[] args) {
        //主线程是默认优先级
        System.out.println(Thread.currentThread().getName()+"-->"+Thread.currentThread().getPriority());    //main-->5

        MyPriority priority = new MyPriority();

        Thread thread1 = new Thread(priority);
        Thread thread2 = new Thread(priority);
        Thread thread3 = new Thread(priority);
        Thread thread4 = new Thread(priority);
        Thread thread5 = new Thread(priority);
        Thread thread6 = new Thread(priority);
        Thread thread7 = new Thread(priority);


        thread1.start();        //Thread-0-->5

        thread2.setPriority(1);     //Thread-1-->1
        thread2.start();

        thread3.setPriority(4);     //Thread-2-->4
        thread3.start();

        thread4.setPriority(Thread.MAX_PRIORITY);   //Thread-3-->10
        thread4.start();

    /*
        main-->5
        Thread-3-->10
        Thread-0-->5
        Thread-2-->4
        Thread-1-->1
     */

    }

}

class MyPriority implements Runnable {

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName()+"-->"+Thread.currentThread().getPriority());
    }
}