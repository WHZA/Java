package com.bean.callable;

import java.util.concurrent.*;

/*
* 1. 实现Callable接口，需要返回值类型
* 2. 重写call方法，需要抛出异常
* 3. 创建目标对象
* 4. 创建执行任务
* 5. 提交执行
* 6. 获取结果
* 7. 关闭服务
* */
public class CallableDemo1 implements Callable<Boolean> {//这里的泛型是Boolean

    private String name;

    public CallableDemo1(String name) {
        this.name = name;
    }

    @Override
    public Boolean call() throws Exception {
        System.out.println("call方法执行："+name);
        return true;//永远返回true
    }




    public static void main(String[] args) {

        //新建了三个callable
        CallableDemo1 callable1 = new CallableDemo1("callable1");
        CallableDemo1 callable2 = new CallableDemo1("callable2");
        CallableDemo1 callable3 = new CallableDemo1("callable3");

        // 创建执行服务，创建了一个线程池，里面有3个线程
        ExecutorService service = Executors.newFixedThreadPool(3);

        //把三个callable提交执行
        Future<Boolean> submit1 = service.submit(callable1);
        Future<Boolean> submit2 = service.submit(callable2);
        Future<Boolean> submit3 = service.submit(callable3);

        //获得结果
        try {
            Boolean result1 = submit1.get();
            Boolean result2 = submit2.get();
            Boolean result3 = submit3.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        //关闭服务
        service.shutdown();
    }

}
