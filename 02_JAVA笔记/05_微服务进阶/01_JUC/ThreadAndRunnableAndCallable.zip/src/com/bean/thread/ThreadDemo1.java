package com.bean.thread;


/*
* 1. 继承Thread
* 2. 重写Run
* 3. 调用start
* */
public class ThreadDemo1 extends Thread{
    @Override
    public void run() {
        for (int i = 0; i < 200; i++) {
            System.out.println("thread的run方法执行了...");
        }
    }


    //主线程执行
    public static void main(String[] args) {

        ThreadDemo1 thread = new ThreadDemo1();

        thread.start();

        for (int i = 0; i < 1000; i++) {
            System.out.println("主线程执行");
        }

    }


}
