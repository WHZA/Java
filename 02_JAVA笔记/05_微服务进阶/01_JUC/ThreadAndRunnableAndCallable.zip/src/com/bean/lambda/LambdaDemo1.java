package com.bean.lambda;

public class LambdaDemo1{

    public static void main(String[] args) {
        ILike like = (i,s)->System.out.println("输出"+i+s);
    }
}

interface ILike{
    void show(int i,String s);
}