package com.bean.connection;

//生产者，消费者，产品，缓冲区，
public class Tube {
    public static void main(String[] args) {

        Synchro synchro = new Synchro();

        new Productor(synchro).start();
        new Consumer(synchro).start();
    }
}

//生产者
class Productor extends Thread{

    Synchro container = new Synchro();

    Productor(Synchro container){
        this.container = container;
    }

    @Override
    public void run() {
        //生产
        for (int i = 0; i < 20; i++) {
            container.push(new Chiken(i));
            System.out.println("生产了第"+i+"只鸡");
        }
    }
}

//消费者
class Consumer extends Thread{

    Synchro container = new Synchro();

    Consumer(Synchro container){
        this.container = container;
    }

    @Override
    public void run() {
        for (int i = 0; i < 20; i++) {
            container.pop();
            System.out.println("消费了第"+i+"只鸡");
        }
    }
}

//产品
class Chiken{
    int id;//产品编号

    public Chiken(int id) {
        this.id = id;
    }
}


//缓冲区
class Synchro{
    //容器大小
    Chiken[] chikens = new Chiken[10];

    int count = 0;//容器计数器

    //生产者放入产品
    public synchronized void push(Chiken chiken){
        //假如容器满了，那么等待消费者消费
        if (count==chikens.length){
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //假如容器没有满，那么就需要丢入产品
        chikens[count] = chiken;
        count++;
        //通知消费者消费
        this.notifyAll();
    }


    //消费者消费产品
    public synchronized Chiken pop(){

        //假如没有鸡，等待生产者生产
        if (count==0){
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        //假如可以消费
        count--;
        Chiken chiken = chikens[count];

        //通知生产者生产
        this.notifyAll();

        return chiken;
    }
}