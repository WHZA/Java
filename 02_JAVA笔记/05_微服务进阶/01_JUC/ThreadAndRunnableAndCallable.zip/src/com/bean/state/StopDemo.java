package com.bean.state;

public class StopDemo implements Runnable {

    //设置一个标志位
    boolean flag = true;

    @Override
    public void run() {
        int i = 0;
        while (flag){
            System.out.println(i+ "");
            i++;
        }
    }

    public void stop(){
        flag = false;
    }

    public static void main(String[] args) {
        StopDemo stop = new StopDemo();

        new Thread(stop).start();

        for (int i = 0; i < 1000000; i++) {
            if (i==900000){
                stop.stop();
            }
        }

    }
}
