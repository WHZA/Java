package com.bean.state;

import com.bean.thread.ThreadDemo1;

/*礼让*/
public class YiledDemo {
    public static void main(String[] args) {
        MyYield yield = new MyYield();
        new Thread(yield,"A").start();
        new Thread(yield,"B").start();
    }
}

class MyYield implements Runnable{

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName()+"线程开始执行");
        Thread.yield();
        System.out.println(Thread.currentThread().getName()+"线程停止执行");
    }
}