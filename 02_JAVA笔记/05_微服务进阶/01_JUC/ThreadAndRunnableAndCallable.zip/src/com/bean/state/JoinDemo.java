package com.bean.state;

public class JoinDemo implements Runnable {
    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            System.out.println("线程vip插队");
        }
    }

    public static void main(String[] args) {
        JoinDemo join = new JoinDemo();
        Thread thread = new Thread(join);
        thread.start();

        for (int i = 0; i < 50; i++) {
            if (i==20){
                try {
                    thread.join();//等待thread插队，插队完成之后才能继续走
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("main"+i);

        }
    }
}