package com.bean.runnable;



/*
* 1. 实现Runnable
* 2. 重写run方法
* 3. 执行线程需要丢入runnable接口的实现类
* 4. 调用start
* */
public class RunnableDemo1 implements Runnable{
    @Override
    public void run() {
        for (int i = 0; i < 200; i++) {
            System.out.println("thread的run方法执行了...");
        }
    }


    //主线程执行
    public static void main(String[] args) {

        RunnableDemo1 runnable = new RunnableDemo1();

        Thread thread = new Thread(runnable);

        thread.start();

        for (int i = 0; i < 1000; i++) {
            System.out.println("main方法执行...");
        }

    }
}
