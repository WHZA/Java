package com.bean.proxy;

//代理对象和真实对象都要实现一个接口
interface Marry{
    void HappyMarry();
}

//真实对象
class Man implements Marry{

    @Override
    public void HappyMarry() {
        System.out.println("男方结婚");
    }
}

//代理对象，婚庆公司
class WeddingCompany implements Marry{

    //代理的目标，真实对象
    private Marry target;

    public WeddingCompany(Marry target) {
        this.target = target;
    }

    @Override
    public void HappyMarry() {
        before();
        //实现真实对象的代理
        target.HappyMarry();
        after();
    }

    private void before(){
        System.out.println("结婚之前布置现场");
    }

    private void after(){
        System.out.println("结婚之后收钱");
    }
}

public class StaticProxy {
    public static void main(String[] args) {
        Man man = new Man();
        new Thread(()->System.out.println("线程")).start();
        new WeddingCompany(man).HappyMarry();
    }

}