package com.bean.blog.service;

import com.bean.blog.pojo.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Bean
 * @since 2020-03-24
 */
public interface UserService extends IService<User> {

}
