package com.bean.blog.mapper;

import com.bean.blog.pojo.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Bean
 * @since 2020-03-24
 */
public interface UserMapper extends BaseMapper<User> {

}
