package com.bean.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bean.pojo.User;
import org.springframework.stereotype.Repository;

//在对应的mapper上实现基本的接口BaseMapper

@Repository
public interface UserMapper extends BaseMapper<User> {
}
