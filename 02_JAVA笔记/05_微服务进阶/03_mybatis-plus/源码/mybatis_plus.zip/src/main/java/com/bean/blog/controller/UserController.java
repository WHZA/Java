package com.bean.blog.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author Bean
 * @since 2020-03-24
 */
@RestController
@RequestMapping("/blog/user")
public class UserController {

}

