package com.bean;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bean.mapper.UserMapper;
import com.bean.pojo.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class WrapperTests {

    @Autowired
    private UserMapper userMapper;

    @Test
    void contextLoads() {

        //name不为空，邮箱不为空，年龄大于12：
        QueryWrapper<User> wrapper = new QueryWrapper<>();

        wrapper.isNotNull("name")//名字不为空
                .isNotNull("email")//邮箱不为空
                .ge("age",12)//大于等于：greater than，equal to，大于等于12
        ;

        userMapper.selectList(wrapper).forEach(System.out::println);

    }

    @Test
    void test2() {

        //name为BEAN：
        QueryWrapper<User> wrapper = new QueryWrapper<>();

        wrapper.eq("name","BEAN");  //equal：等于

        //selectOne:查询一个数据
        System.out.println(userMapper.selectOne(wrapper));

    }


    @Test
    void test3() {

        //查询年龄在20~30之间的用户有多少
        QueryWrapper<User> wrapper = new QueryWrapper<>();

        wrapper.between("name",20,30);  //between：在xx~xx之间

        //selectCount:查询一个总数据
        System.out.println(userMapper.selectCount(wrapper));

    }

    @Test
    void test4() {

        //模糊查询，名字里不包含e，包含k的
        QueryWrapper<User> wrapper = new QueryWrapper<>();

        wrapper.notLike("name","e").like("name","k");


        userMapper.selectMaps(wrapper).forEach(System.out::println);

    }

    @Test
    void test5() {

        //模糊查询，左查询：%xxx，右查询：xxx%
        //查询邮箱以t开头的，就是t%，也就是likeRight
        QueryWrapper<User> wrapper = new QueryWrapper<>();

        wrapper.likeRight("email","t");


        userMapper.selectMaps(wrapper).forEach(System.out::println);

    }

    @Test
    void test6() {

        //内查询，sql嵌套sql查询
        QueryWrapper<User> wrapper = new QueryWrapper<>();

        wrapper.inSql("id","select id from user where id< 3");


        userMapper.selectObjs(wrapper).forEach(System.out::println);

    }


    @Test
    void test7() {

        //通过id进行排序
        QueryWrapper<User> wrapper = new QueryWrapper<>();

        //通过id进行降序排序
        wrapper.orderByDesc("id");

        userMapper.selectList(wrapper).forEach(System.out::println);

    }


}
