package com.bean;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bean.mapper.UserMapper;
import com.bean.pojo.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@SpringBootTest
class MybatisPlusApplicationTests {

    @Autowired
    private UserMapper userMapper;

    @Test
    void contextLoads() {

        //查询所有用户，参数是一个条件构造器，不用就写null
        List<User> users = userMapper.selectList(null);
        for (User user : users) {
            System.out.println(user);
        }

    }

    @Test
    void testInsert() {

        User user = new User().setName("BEAN").setAge(20).setEmail("xxx@qq.com");
        System.out.println(user);
        int insert = userMapper.insert(user);
        System.out.println(insert);
    }


    @Test
    void testUpdate() {
        User user = new User().setId(1240941797300097026L).setName("howling").setAge(20).setEmail("xxx@163.com");
        userMapper.updateById(user);//这里需要的是user不是id
    }



    //测试乐观锁，成功案例
    @Test
    void testOptimisticLockerSuccess() {

        //1. 查询用户信息
        User user = userMapper.selectById(1L);

        //2. 修改用户信息
        user.setName("ISHOWLING").setEmail("123@123.com");
        userMapper.updateById(user);
    }

    //测试乐观锁，失败案例
    @Test
    void testOptimisticLockerFail() {
        //线程1
        User user = userMapper.selectById(1L);
        user.setName("ISHOWLING").setEmail("123@123.com");

        //线程2，模拟另外的线程执行插队操作
        User user2 = userMapper.selectById(1L);
        user2.setName("ISHOWLINGGGGG").setEmail("123123123@123.com");
        //线程2先执行
        userMapper.updateById(user2);

        //线程1后执行
        userMapper.updateById(user);

    }



    @Test
    void testSelect() {

        //查询单个ID
        List<User> users = userMapper.selectList(null);
        users.forEach(System.out::println);

    }

    @Test
    void testPage() {
        //参数一：当前页，参数二：页面大小
        Page<User> page = new Page<>(2,5);
        userMapper.selectPage(page,null);

    }

    @Test
    void testDelete() {
        //根据ID删除
        userMapper.deleteById(1L);

    }
}
