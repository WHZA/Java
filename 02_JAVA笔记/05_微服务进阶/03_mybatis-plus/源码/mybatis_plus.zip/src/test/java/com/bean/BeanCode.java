package com.bean;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.DataSourceConfig;
import com.baomidou.mybatisplus.generator.config.GlobalConfig;
import com.baomidou.mybatisplus.generator.config.PackageConfig;
import com.baomidou.mybatisplus.generator.config.StrategyConfig;
import com.baomidou.mybatisplus.generator.config.po.TableFill;
import com.baomidou.mybatisplus.generator.config.rules.DateType;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.sun.javaws.jnl.ResourcesDesc;

import java.util.ArrayList;

public class BeanCode {

    public static void main(String[] args) {

        AutoGenerator autoGenerator = new AutoGenerator();

        //1. 全局配置：import com.baomidou.mybatisplus.generator.config.GlobalConfig;
        GlobalConfig config = new GlobalConfig();

        String property = System.getProperty("user.dir");//当前项目路径

        config.setOutputDir(property+"/src/main/java");//输出路径：生成的代码到当前项目路径/src/main/java下

        config.setAuthor("Bean");//作者

        config.setOpen(false);//是否打开资源管理器

        config.setFileOverride(false);//是否覆盖原来的代码

        config.setServiceName("%sService");//去掉Service的I前缀

        config.setIdType(IdType.ID_WORKER);//默认的ID生成策略

        config.setDateType(DateType.ONLY_DATE);//日期的类型

        config.setSwagger2(true);//设置Swagger


        autoGenerator.setGlobalConfig(config);//设置好全局配置

        //2. 设置数据源配置
        DataSourceConfig dataSource = new DataSourceConfig();

        dataSource.setUrl("jdbc:mysql://localhost:3306/mybatis_plus?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai");
        dataSource.setDriverName("com.mysql.cj.jdbc.Driver");
        dataSource.setUsername("root");
        dataSource.setPassword("root");
        dataSource.setDbType(DbType.MYSQL);//设置数据库的类型
        autoGenerator.setDataSource(dataSource);    //设置好数据源配置

        //3. 包的配置
        PackageConfig packageConfig = new PackageConfig();

        packageConfig.setModuleName("blog");//模块名字
        packageConfig.setParent("com.bean");//放到哪个包下,那么就是com.bean.blog
        packageConfig.setEntity("pojo");//实体类的名字
        packageConfig.setMapper("mapper");//映射的名字
        packageConfig.setService("service");//Service名字
        packageConfig.setController("controller");//Controller的名字
        autoGenerator.setPackageInfo(packageConfig);//设置包的配置


        //4. 策略配置
        StrategyConfig strategy = new StrategyConfig();
        strategy.setInclude("user");//设置要映射的表名，这里是一个可变参数，可以设置多张表
        strategy.setNaming(NamingStrategy.underline_to_camel);//下划线转驼峰
        strategy.setColumnNaming(NamingStrategy.underline_to_camel);//下划线转驼峰
        strategy.setEntityLombokModel(true);//是否使用lombok开启注解

        strategy.setLogicDeleteFieldName("deleted");//逻辑删除字段

        TableFill createTime = new TableFill("create_time", FieldFill.INSERT);//自动填充，创建时间
        TableFill updateTime = new TableFill("update_time", FieldFill.UPDATE);//自动填充，修改时间

        ArrayList<TableFill> tableFills = new ArrayList<>();
        tableFills.add(createTime);
        tableFills.add(updateTime);
        strategy.setTableFillList(tableFills);  //添加到自动填充

        strategy.setVersionFieldName("version");//乐观锁

        strategy.setRestControllerStyle(true);//开启Controller的Rest的驼峰命名格式

        strategy.setControllerMappingHyphenStyle(true);//开启Controller的下划线形式：localhost:8080/hello_id_2

        autoGenerator.setStrategy(strategy);    //策略配置

        autoGenerator.execute();//执行

    }
}
