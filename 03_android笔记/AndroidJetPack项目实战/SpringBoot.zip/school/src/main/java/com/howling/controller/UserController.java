package com.howling.controller;

import com.howling.mapper.UserMapper;
import com.howling.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserMapper mapper;

    @RequestMapping("/login")
    public User selectUserByMap(String username,String password){
        return mapper.selectUserByMap(new User().setUsername(username).setPassword(password));
    }
}